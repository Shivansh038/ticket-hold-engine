import os
import random
from typing import Dict, List, Optional, Set, Tuple
import unittest

from ticket_engine.clock import FakeClock
from ticket_engine.engine import TicketHoldEngine
from ticket_engine.models import (
    HoldAlreadyConfirmedError,
    HoldAlreadyReleasedError,
    HoldInvalidatedError,
    HoldLimitExceededError,
    HoldNotFoundError,
    SeatAlreadyHeldError,
    SeatAlreadySoldError,
    SeatState,
    SeatStatus,
    TicketEngineError,
)


class ReferenceTicketEngine:
    """A deliberately simple, single-threaded reference implementation

    used as an oracle for model-based property testing.
    """

    def __init__(self, clock: FakeClock) -> None:
        self.clock = clock
        self.seats: Dict[str, dict] = {}  # seat_id -> {"sold_to": str|None, "current_hold_id": str|None}
        self.holds: Dict[str, dict] = {}  # hold_id -> {fields}
        self.user_holds: Dict[str, Set[str]] = {}
        self.hold_counter = 0

    def _get_seat(self, seat_id: str) -> dict:
        if seat_id not in self.seats:
            self.seats[seat_id] = {"sold_to": None, "current_hold_id": None}
        return self.seats[seat_id]

    def _get_user_active_seats(self, user_id: str) -> Set[str]:
        now = self.clock.now()
        active = set()
        for hid in self.user_holds.get(user_id, set()):
            h = self.holds.get(hid)
            if not h:
                continue
            seat = self._get_seat(h["seat_id"])
            if (
                not h["released"]
                and not h["confirmed"]
                and not h["superseded"]
                and h["expires_at"] > now
                and seat["current_hold_id"] == hid
            ):
                active.add(h["seat_id"])
        return active

    def hold_many(self, user_id: str, seat_ids: List[str], ttl_seconds: float) -> List[str]:
        if not seat_ids:
            return []
        now = self.clock.now()
        unique_seats = sorted(set(seat_ids))

        active_seats = self._get_user_active_seats(user_id)
        new_seats = [s for s in unique_seats if s not in active_seats]

        # Quota check
        if len(active_seats) + len(new_seats) > 4:
            raise HoldLimitExceededError("Quota exceeded in reference model")

        # Availability check
        for s in unique_seats:
            seat = self._get_seat(s)
            if seat["sold_to"] is not None:
                raise SeatAlreadySoldError(f"Seat {s} sold in reference model")
            if seat["current_hold_id"] is not None:
                h = self.holds[seat["current_hold_id"]]
                if not h["released"] and not h["superseded"] and h["expires_at"] > now:
                    if h["user_id"] != user_id:
                        raise SeatAlreadyHeldError(f"Seat {s} held in reference model")

        # Mutation
        res_map = {}
        for s in unique_seats:
            seat = self._get_seat(s)
            if s in active_seats:
                res_map[s] = seat["current_hold_id"]
            else:
                if seat["current_hold_id"] is not None:
                    old_h = self.holds.get(seat["current_hold_id"])
                    if old_h:
                        old_h["superseded"] = True

                self.hold_counter += 1
                new_hid = f"ref_hold_{self.hold_counter}"
                self.holds[new_hid] = {
                    "hold_id": new_hid,
                    "seat_id": s,
                    "user_id": user_id,
                    "created_at": now,
                    "expires_at": now + ttl_seconds,
                    "confirmed": False,
                    "released": False,
                    "superseded": False,
                }
                if user_id not in self.user_holds:
                    self.user_holds[user_id] = set()
                self.user_holds[user_id].add(new_hid)
                seat["current_hold_id"] = new_hid
                res_map[s] = new_hid

        return [res_map[s] for s in seat_ids]

    def hold(self, seat_id: str, user_id: str, ttl_seconds: float) -> str:
        return self.hold_many(user_id, [seat_id], ttl_seconds)[0]

    def confirm(self, hold_id: str) -> str:
        h = self.holds.get(hold_id)
        if not h:
            raise HoldNotFoundError(f"Hold {hold_id} not found in reference model")

        if h["confirmed"]:
            raise HoldAlreadyConfirmedError("Already confirmed")
        if h["released"]:
            raise HoldAlreadyReleasedError("Already released")
        if h["superseded"]:
            raise HoldInvalidatedError("Superseded")

        seat = self._get_seat(h["seat_id"])
        if seat["sold_to"] is not None:
            raise SeatAlreadySoldError("Seat already sold")
        if seat["current_hold_id"] != hold_id:
            raise HoldInvalidatedError("Seat retaken")

        seat["sold_to"] = h["user_id"]
        seat["current_hold_id"] = None
        h["confirmed"] = True
        return "OK"

    def release(self, hold_id: str) -> str:
        h = self.holds.get(hold_id)
        if not h:
            raise HoldNotFoundError(f"Hold {hold_id} not found in reference model")

        if h["confirmed"]:
            raise HoldAlreadyConfirmedError("Cannot release sold seat")
        if h["released"]:
            raise HoldAlreadyReleasedError("Already released")

        seat = self._get_seat(h["seat_id"])
        if seat["current_hold_id"] == hold_id:
            seat["current_hold_id"] = None
        h["released"] = True
        return "OK"

    def seat_status(self, seat_id: str) -> SeatStatus:
        seat = self._get_seat(seat_id)
        if seat["sold_to"] is not None:
            return SeatStatus(status=SeatState.SOLD, user_id=seat["sold_to"])
        if seat["current_hold_id"] is not None:
            h = self.holds.get(seat["current_hold_id"])
            if h and not h["released"] and not h["superseded"]:
                if h["expires_at"] > self.clock.now():
                    return SeatStatus(
                        status=SeatState.HELD,
                        user_id=h["user_id"],
                        expires_at=h["expires_at"],
                    )
        return SeatStatus(status=SeatState.FREE)


class TestModelBasedRandomized(unittest.TestCase):
    """Model-based testing: compares the TicketHoldEngine against a single-threaded

    reference oracle over a randomized sequence of operations.
    """

    def test_randomized_differential_testing(self) -> None:
        seed = int(os.environ.get("MODEL_TEST_SEED", random.randint(10000, 99999)))
        print(f"\n[MODEL TEST] Reproducible seed: {seed}")
        rng = random.Random(seed)

        clock = FakeClock(0.0)
        engine = TicketHoldEngine(clock=clock)
        oracle = ReferenceTicketEngine(clock=clock)

        seats = ["S1", "S2", "S3", "S4", "S5", "S6"]
        users = ["alice", "bob", "charlie", "dave"]

        # Track hold_id mapping between engine and oracle
        # engine_hold_id -> oracle_hold_id
        engine_to_oracle_hold: Dict[str, str] = {}
        oracle_to_engine_hold: Dict[str, str] = {}

        steps = 500
        for step in range(steps):
            op = rng.choice(["hold", "hold_many", "confirm", "release", "status", "advance_clock"])

            if op == "hold":
                seat = rng.choice(seats)
                user = rng.choice(users)
                ttl = rng.choice([5.0, 10.0, 20.0])

                engine_err = None
                oracle_err = None
                engine_hid = None
                oracle_hid = None

                try:
                    engine_hid = engine.hold(seat, user, ttl)
                except Exception as e:
                    engine_err = type(e)

                try:
                    oracle_hid = oracle.hold(seat, user, ttl)
                except Exception as e:
                    oracle_err = type(e)

                self.assertEqual(
                    engine_err,
                    oracle_err,
                    f"Step {step} (hold): Engine error {engine_err} != Oracle error {oracle_err}",
                )

                if engine_err is None:
                    engine_to_oracle_hold[engine_hid] = oracle_hid
                    oracle_to_engine_hold[oracle_hid] = engine_hid

            elif op == "hold_many":
                batch_size = rng.randint(1, 4)
                chosen_seats = rng.choices(seats, k=batch_size)  # May contain duplicates to test deduplication
                user = rng.choice(users)
                ttl = rng.choice([5.0, 10.0, 20.0])

                engine_err = None
                oracle_err = None
                engine_hids = None
                oracle_hids = None

                try:
                    engine_hids = engine.hold_many(user, chosen_seats, ttl)
                except Exception as e:
                    engine_err = type(e)

                try:
                    oracle_hids = oracle.hold_many(user, chosen_seats, ttl)
                except Exception as e:
                    oracle_err = type(e)

                self.assertEqual(
                    engine_err,
                    oracle_err,
                    f"Step {step} (hold_many): Engine error {engine_err} != Oracle error {oracle_err}",
                )

                if engine_err is None and engine_hids and oracle_hids:
                    self.assertEqual(len(engine_hids), len(oracle_hids))
                    for eh, oh in zip(engine_hids, oracle_hids):
                        engine_to_oracle_hold[eh] = oh
                        oracle_to_engine_hold[oh] = eh

            elif op == "confirm":
                if not engine_to_oracle_hold:
                    continue
                # Pick an existing hold or a non-existent hold
                if rng.random() < 0.1:
                    target_e = "nonexistent_hold_id"
                    target_o = "nonexistent_hold_id"
                else:
                    target_e = rng.choice(list(engine_to_oracle_hold.keys()))
                    target_o = engine_to_oracle_hold[target_e]

                engine_err = None
                oracle_err = None

                try:
                    engine.confirm(target_e)
                except Exception as e:
                    engine_err = type(e)

                try:
                    oracle.confirm(target_o)
                except Exception as e:
                    oracle_err = type(e)

                self.assertEqual(
                    engine_err,
                    oracle_err,
                    f"Step {step} (confirm): Engine error {engine_err} != Oracle error {oracle_err}",
                )

            elif op == "release":
                if not engine_to_oracle_hold:
                    continue
                if rng.random() < 0.1:
                    target_e = "nonexistent_hold_id"
                    target_o = "nonexistent_hold_id"
                else:
                    target_e = rng.choice(list(engine_to_oracle_hold.keys()))
                    target_o = engine_to_oracle_hold[target_e]

                engine_err = None
                oracle_err = None

                try:
                    engine.release(target_e)
                except Exception as e:
                    engine_err = type(e)

                try:
                    oracle.release(target_o)
                except Exception as e:
                    oracle_err = type(e)

                self.assertEqual(
                    engine_err,
                    oracle_err,
                    f"Step {step} (release): Engine error {engine_err} != Oracle error {oracle_err}",
                )

            elif op == "status":
                s = rng.choice(seats)
                e_status = engine.seat_status(s)
                o_status = oracle.seat_status(s)

                self.assertEqual(e_status.status, o_status.status, f"Step {step}: Status mismatch on seat {s}")
                self.assertEqual(e_status.user_id, o_status.user_id, f"Step {step}: User mismatch on seat {s}")
                if e_status.status == SeatState.HELD:
                    self.assertAlmostEqual(e_status.expires_at, o_status.expires_at, delta=1e-5)

            elif op == "advance_clock":
                delta = rng.choice([1.0, 5.0, 15.0])
                clock.advance(delta)

        # Final state verification across all seats
        for s in seats:
            e_status = engine.seat_status(s)
            o_status = oracle.seat_status(s)
            self.assertEqual(e_status.status, o_status.status)
            self.assertEqual(e_status.user_id, o_status.user_id)
            if e_status.status == SeatState.HELD:
                self.assertAlmostEqual(e_status.expires_at, o_status.expires_at, delta=1e-5)

        print(f"[MODEL TEST] Passed! Differential testing succeeded across {steps} random operations.")


if __name__ == "__main__":
    unittest.main()
