from collections import defaultdict
import os
import random
import threading
import time
from typing import Dict, List, Set, Tuple
import unittest

from ticket_engine.clock import Clock
from ticket_engine.engine import TicketHoldEngine
from ticket_engine.models import (
    SeatAlreadyHeldError,
    SeatAlreadySoldError,
    SeatState,
    TicketEngineError,
)


class ThreadSafeFakeClock:
    """Thread-safe fake clock allowing threads to read and monotonically advance time."""

    def __init__(self, initial_time: float = 100.0) -> None:
        self._current_time: float = initial_time
        self._lock = threading.Lock()

    def now(self) -> float:
        with self._lock:
            return self._current_time

    def advance(self, delta: float) -> None:
        with self._lock:
            self._current_time += delta


class TestConcurrencyStress(unittest.TestCase):
    """Multi-threaded stress testing asserting invariants under heavy contention."""

    def test_concurrency_stress_invariants(self) -> None:
        seed = int(os.environ.get("CONCURRENCY_TEST_SEED", random.randint(10000, 99999)))
        print(f"\n[STRESS TEST] Reproducible seed: {seed}")
        rng = random.Random(seed)

        clock = ThreadSafeFakeClock(initial_time=0.0)
        engine = TicketHoldEngine(clock=clock)

        seats = ["S1", "S2", "S3", "S4", "S5"]
        users = ["user_1", "user_2", "user_3", "user_4", "user_5"]

        # Audit logs to verify invariants post-run
        audit_lock = threading.Lock()
        successful_holds: List[dict] = []  # dict with hold_id, user, seat, created_at, expires_at
        successful_confirms: List[dict] = []  # dict with hold_id, user, seat, time
        max_observed_user_holds: Dict[str, int] = defaultdict(int)

        # Shared bag of currently known holds that threads can attempt to confirm or release
        known_hold_ids: List[str] = []

        stop_event = threading.Event()
        num_threads = 8
        operations_per_thread = 200

        def worker(thread_id: int, thread_seed: int) -> None:
            thread_rng = random.Random(thread_seed)

            for _ in range(operations_per_thread):
                if stop_event.is_set():
                    break

                op = thread_rng.choice(["hold", "hold_many", "confirm", "release", "tick"])
                user = thread_rng.choice(users)

                try:
                    if op == "hold":
                        seat = thread_rng.choice(seats)
                        ttl = thread_rng.choice([2.0, 5.0, 10.0])
                        now = clock.now()
                        hid = engine.hold(seat, user, ttl)

                        with audit_lock:
                            known_hold_ids.append(hid)
                            successful_holds.append({
                                "hold_id": hid,
                                "user": user,
                                "seat": seat,
                                "created_at": now,
                                "expires_at": now + ttl,
                            })

                    elif op == "hold_many":
                        batch_size = thread_rng.randint(1, 4)
                        chosen_seats = thread_rng.sample(seats, batch_size)
                        ttl = thread_rng.choice([2.0, 5.0, 10.0])
                        now = clock.now()
                        hids = engine.hold_many(user, chosen_seats, ttl)

                        with audit_lock:
                            for s, hid in zip(chosen_seats, hids):
                                known_hold_ids.append(hid)
                                successful_holds.append({
                                    "hold_id": hid,
                                    "user": user,
                                    "seat": s,
                                    "created_at": now,
                                    "expires_at": now + ttl,
                                })

                    elif op == "confirm":
                        target_hid = None
                        with audit_lock:
                            if known_hold_ids:
                                target_hid = thread_rng.choice(known_hold_ids)
                        if target_hid:
                            now = clock.now()
                            engine.confirm(target_hid)
                            # Confirmation succeeded!
                            with audit_lock:
                                # Find hold info
                                h_info = next((h for h in successful_holds if h["hold_id"] == target_hid), None)
                                if h_info:
                                    successful_confirms.append({
                                        "hold_id": target_hid,
                                        "user": h_info["user"],
                                        "seat": h_info["seat"],
                                        "confirmed_at": now,
                                        "expires_at": h_info["expires_at"],
                                        "created_at": h_info["created_at"],
                                    })

                    elif op == "release":
                        target_hid = None
                        with audit_lock:
                            if known_hold_ids:
                                target_hid = thread_rng.choice(known_hold_ids)
                        if target_hid:
                            engine.release(target_hid)

                    elif op == "tick":
                        # Advance clock slightly
                        clock.advance(thread_rng.uniform(0.5, 2.0))

                except TicketEngineError:
                    # Expected business rejections under race conditions
                    pass
                except Exception as e:
                    stop_event.set()
                    raise e

        # Spawn workers
        threads = []
        for i in range(num_threads):
            t_seed = rng.randint(1, 1000000)
            t = threading.Thread(target=worker, args=(i, t_seed))
            threads.append(t)
            t.start()

        for t in threads:
            t.join(timeout=15.0)
            self.assertFalse(t.is_alive(), "Worker thread timed out - possible deadlock!")

        self.assertFalse(stop_event.is_set(), "Unexpected exception occurred during stress test")

        # -----------------------------------------------------------------
        # ASSERT INVARIANT 1: No Double Sale
        # A seat can be sold at most once across the entire run.
        # -----------------------------------------------------------------
        confirmed_seats: Dict[str, List[dict]] = defaultdict(list)
        for conf in successful_confirms:
            confirmed_seats[conf["seat"]].append(conf)

        for seat, confirms in confirmed_seats.items():
            self.assertEqual(
                len(confirms),
                1,
                f"INVARIANT VIOLATION: Seat {seat} was sold {len(confirms)} times! Confirms: {confirms}",
            )
            # Seat status in engine must reflect SOLD to that exact user
            status = engine.seat_status(seat)
            self.assertEqual(status.status, SeatState.SOLD)
            self.assertEqual(status.user_id, confirms[0]["user"])

        # -----------------------------------------------------------------
        # ASSERT INVARIANT 2: No User Over 4 Holds
        # At any instant, no user could have more than 4 active holds.
        # -----------------------------------------------------------------
        # Check final active holds for all users
        now = clock.now()
        for u in users:
            active_seats_count = 0
            for s in seats:
                st = engine.seat_status(s)
                if st.status == SeatState.HELD and st.user_id == u:
                    active_seats_count += 1
            self.assertLessEqual(
                active_seats_count,
                4,
                f"INVARIANT VIOLATION: User {u} has {active_seats_count} active holds at end of test",
            )

        # -----------------------------------------------------------------
        # ASSERT INVARIANT 3: No Confirmed Expired-and-Retaken Hold
        # If hold H on seat S was confirmed, either:
        # 1. It was confirmed before expiration, OR
        # 2. It expired, but NO other hold was granted on seat S between H and confirm.
        # -----------------------------------------------------------------
        for conf in successful_confirms:
            seat = conf["seat"]
            h_created = conf["created_at"]
            h_confirmed = conf["confirmed_at"]
            h_id = conf["hold_id"]

            # Any holds on this seat created after this hold?
            subsequent_holds = [
                h for h in successful_holds
                if h["seat"] == seat
                and h["created_at"] >= h_created
                and h["hold_id"] != h_id
            ]

            # If there was a subsequent hold granted before confirmation, this is a violation!
            for intervening_hold in subsequent_holds:
                self.assertGreaterEqual(
                    intervening_hold["created_at"],
                    h_confirmed,
                    f"INVARIANT VIOLATION: Hold {h_id} was confirmed at {h_confirmed} even though "
                    f"seat {seat} was retaken by {intervening_hold['hold_id']} at {intervening_hold['created_at']}!",
                )

        print(f"[STRESS TEST] Passed! Processed {len(successful_holds)} holds and {len(successful_confirms)} sales without invariant violations.")

    def test_deadlock_freedom_overlapping_reverse_order(self) -> None:
        """Specifically verifies that two threads requesting overlapping seat sets

        in reverse order simultaneously do not deadlock.
        """
        clock = ThreadSafeFakeClock(0.0)
        engine = TicketHoldEngine(clock=clock)

        rounds = 200
        errors = []

        def task_a() -> None:
            for _ in range(rounds):
                try:
                    engine.hold_many("user_a", ["seat_1", "seat_2"], 5.0)
                except TicketEngineError:
                    pass
                clock.advance(0.1)

        def task_b() -> None:
            for _ in range(rounds):
                try:
                    # Reverse order
                    engine.hold_many("user_b", ["seat_2", "seat_1"], 5.0)
                except TicketEngineError:
                    pass
                clock.advance(0.1)

        t1 = threading.Thread(target=task_a)
        t2 = threading.Thread(target=task_b)

        t1.start()
        t2.start()

        t1.join(timeout=5.0)
        t2.join(timeout=5.0)

        self.assertFalse(t1.is_alive(), "Deadlock detected: Task A hung while acquiring locks!")
        self.assertFalse(t2.is_alive(), "Deadlock detected: Task B hung while acquiring locks!")


if __name__ == "__main__":
    unittest.main()
