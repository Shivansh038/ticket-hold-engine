import unittest

from ticket_engine.clock import FakeClock
from ticket_engine.engine import TicketHoldEngine
from ticket_engine.models import (
    HoldAlreadyConfirmedError,
    HoldAlreadyReleasedError,
    HoldInvalidatedError,
    HoldLimitExceededError,
    HoldNotFoundError,
    SeatAlreadyHeldError,
    SeatAlreadySoldError,
    SeatState,
)


class TestTicketHoldEngineRules(unittest.TestCase):
    def setUp(self) -> None:
        self.clock = FakeClock(initial_time=100.0)
        self.engine = TicketHoldEngine(clock=self.clock)

    # -------------------------------------------------------------
    # R1: At most one user holds a seat; sold at most once
    # -------------------------------------------------------------
    def test_r1_exclusive_hold(self) -> None:
        h1 = self.engine.hold("A1", "alice", 30)
        self.assertTrue(h1.startswith("hold_"))
        status = self.engine.seat_status("A1")
        self.assertEqual(status.status, SeatState.HELD)
        self.assertEqual(status.user_id, "alice")
        self.assertEqual(status.expires_at, 130.0)

        # Bob cannot hold A1 while Alice actively holds it
        with self.assertRaises(SeatAlreadyHeldError):
            self.engine.hold("A1", "bob", 30)

    def test_r1_sold_at_most_once(self) -> None:
        h1 = self.engine.hold("A1", "alice", 30)
        res = self.engine.confirm(h1)
        self.assertEqual(res, "OK")

        status = self.engine.seat_status("A1")
        self.assertEqual(status.status, SeatState.SOLD)
        self.assertEqual(status.user_id, "alice")

        # Confirming again fails
        with self.assertRaises(HoldAlreadyConfirmedError):
            self.engine.confirm(h1)

        # Another user cannot hold or buy a sold seat
        with self.assertRaises(SeatAlreadySoldError):
            self.engine.hold("A1", "bob", 30)

    # -------------------------------------------------------------
    # R2: User may hold at most 4 seats at once
    # -------------------------------------------------------------
    def test_r2_max_four_holds_per_user(self) -> None:
        h1 = self.engine.hold("A1", "alice", 30)
        h2 = self.engine.hold("A2", "alice", 30)
        h3 = self.engine.hold("A3", "alice", 30)
        h4 = self.engine.hold("A4", "alice", 30)

        # 5th hold exceeds limit
        with self.assertRaises(HoldLimitExceededError):
            self.engine.hold("A5", "alice", 30)

        # Releasing one seat frees up quota
        self.engine.release(h1)
        h5 = self.engine.hold("A5", "alice", 30)
        self.assertTrue(h5.startswith("hold_"))

    def test_r2_expired_holds_do_not_block_quota(self) -> None:
        # Alice holds 4 seats
        for i in range(1, 5):
            self.engine.hold(f"A{i}", "alice", 10)

        # Advance clock past TTL
        self.clock.advance(15)  # t=115

        # Alice's 4 holds are now expired; she should be able to hold 4 new seats
        for i in range(5, 9):
            self.engine.hold(f"A{i}", "alice", 10)

    # -------------------------------------------------------------
    # R3: Expired hold can be confirmed iff uncontested
    # -------------------------------------------------------------
    def test_r3_expired_hold_confirmed_when_uncontested(self) -> None:
        h1 = self.engine.hold("A1", "alice", 20)  # expires at 120.0
        self.clock.advance(30)  # now t=130 (expired)

        # Status reports FREE to the world
        self.assertEqual(self.engine.seat_status("A1").status, SeatState.FREE)

        # Nobody took the seat in the meantime; Alice confirms successfully
        res = self.engine.confirm(h1)
        self.assertEqual(res, "OK")
        self.assertEqual(self.engine.seat_status("A1").status, SeatState.SOLD)
        self.assertEqual(self.engine.seat_status("A1").user_id, "alice")

    def test_r3_expired_hold_rejected_if_retaken(self) -> None:
        h1 = self.engine.hold("A1", "alice", 20)  # expires at 120.0
        self.clock.advance(25)  # now t=125

        # Bob takes the seat after Alice expired
        h2 = self.engine.hold("A1", "bob", 30)
        self.assertNotEqual(h1, h2)

        # Alice attempts late payment confirmation -> rejected because Bob took it
        with self.assertRaises(HoldInvalidatedError):
            self.engine.confirm(h1)

    def test_r3_expired_hold_rejected_if_retaken_and_then_released(self) -> None:
        h1 = self.engine.hold("A1", "alice", 20)  # expires at 120.0
        self.clock.advance(25)  # now t=125

        # Bob takes the seat, then releases it
        h2 = self.engine.hold("A1", "bob", 30)
        self.engine.release(h2)

        # Even though seat is currently FREE, Bob took it in the meantime, so Alice cannot confirm
        with self.assertRaises(HoldInvalidatedError):
            self.engine.confirm(h1)

    # -------------------------------------------------------------
    # R4 & R5: Idempotent retries and holds are never extended
    # -------------------------------------------------------------
    def test_r5_idempotent_retry_returns_same_hold_id(self) -> None:
        h1 = self.engine.hold("A1", "alice", 20)
        self.clock.advance(5)  # t=105

        # Flaky network retry: same user, same seat
        h2 = self.engine.hold("A1", "alice", 20)
        self.assertEqual(h1, h2)

        # Expiration must NOT be extended (R4: holds are final)
        status = self.engine.seat_status("A1")
        self.assertEqual(status.expires_at, 120.0)

    def test_r4_retry_does_not_extend_expiry(self) -> None:
        self.engine.hold("A1", "alice", 10)  # expires at 110.0
        self.clock.advance(8)  # t=108

        # Retry requesting 30s TTL
        self.engine.hold("A1", "alice", 30)

        # Must still expire at original 110.0
        self.clock.advance(3)  # t=111
        self.assertEqual(self.engine.seat_status("A1").status, SeatState.FREE)

    def test_retry_on_expired_uncontested_creates_new_hold(self) -> None:
        h1 = self.engine.hold("A1", "alice", 10)  # expires at 110.0
        self.clock.advance(15)  # t=115 (expired)

        # User calls hold() again after hold has already expired
        h2 = self.engine.hold("A1", "alice", 20)  # new hold from t=115 to t=135
        self.assertNotEqual(h1, h2)

        status = self.engine.seat_status("A1")
        self.assertEqual(status.status, SeatState.HELD)
        self.assertEqual(status.expires_at, 135.0)

        # Old hold is superseded and cannot be confirmed
        with self.assertRaises(HoldInvalidatedError):
            self.engine.confirm(h1)

    # -------------------------------------------------------------
    # R6: hold_many is all-or-nothing
    # -------------------------------------------------------------
    def test_r6_hold_many_atomic_success(self) -> None:
        hids = self.engine.hold_many("alice", ["A1", "A2", "A3"], 30)
        self.assertEqual(len(hids), 3)
        self.assertEqual(len(set(hids)), 3)

        for s in ["A1", "A2", "A3"]:
            self.assertEqual(self.engine.seat_status(s).status, SeatState.HELD)

    def test_r6_hold_many_atomic_rollback_on_conflict(self) -> None:
        # Bob already holds A2
        self.engine.hold("A2", "bob", 30)

        # Alice attempts to hold A1, A2, A3
        with self.assertRaises(SeatAlreadyHeldError):
            self.engine.hold_many("alice", ["A1", "A2", "A3"], 30)

        # All-or-nothing: Neither A1 nor A3 should be held by Alice
        self.assertEqual(self.engine.seat_status("A1").status, SeatState.FREE)
        self.assertEqual(self.engine.seat_status("A3").status, SeatState.FREE)

    def test_r6_hold_many_atomic_rollback_on_quota_overflow(self) -> None:
        self.engine.hold("A1", "alice", 30)
        self.engine.hold("A2", "alice", 30)

        # Alice holds 2 seats. Requesting 3 more would exceed limit of 4.
        with self.assertRaises(HoldLimitExceededError):
            self.engine.hold_many("alice", ["A3", "A4", "A5"], 30)

        # None of A3, A4, A5 should be held
        self.assertEqual(self.engine.seat_status("A3").status, SeatState.FREE)
        self.assertEqual(self.engine.seat_status("A4").status, SeatState.FREE)
        self.assertEqual(self.engine.seat_status("A5").status, SeatState.FREE)

    def test_r6_hold_many_idempotent_overlap(self) -> None:
        # Alice already holds A1
        h1 = self.engine.hold("A1", "alice", 30)

        # Alice requests [A1, A2] -> A1 is retry, A2 is new
        hids = self.engine.hold_many("alice", ["A1", "A2"], 30)
        self.assertEqual(len(hids), 2)
        self.assertEqual(hids[0], h1)  # Reuses existing hold
        self.assertNotEqual(hids[1], h1)

        self.assertEqual(self.engine.seat_status("A1").status, SeatState.HELD)
        self.assertEqual(self.engine.seat_status("A2").status, SeatState.HELD)

    def test_release_functionality(self) -> None:
        h1 = self.engine.hold("A1", "alice", 30)
        self.assertEqual(self.engine.release(h1), "OK")
        self.assertEqual(self.engine.seat_status("A1").status, SeatState.FREE)

        # Releasing again fails
        with self.assertRaises(HoldAlreadyReleasedError):
            self.engine.release(h1)

        # Cannot release a confirmed seat
        h2 = self.engine.hold("A2", "alice", 30)
        self.engine.confirm(h2)
        with self.assertRaises(HoldAlreadyConfirmedError):
            self.engine.release(h2)


if __name__ == "__main__":
    unittest.main()
