from collections import defaultdict
from dataclasses import dataclass
import threading
from typing import Callable, Dict, List, Optional, Set
import uuid

from .clock import Clock, SystemClock
from .models import (
    HoldAlreadyConfirmedError,
    HoldAlreadyReleasedError,
    HoldInvalidatedError,
    HoldLimitExceededError,
    HoldNotFoundError,
    HoldRecord,
    SeatAlreadyHeldError,
    SeatAlreadySoldError,
    SeatState,
    SeatStatus,
    TicketEngineError,
)


@dataclass
class _SeatInternal:
    seat_id: str
    sold_to: Optional[str] = None
    current_hold_id: Optional[str] = None


class TicketHoldEngine:
    """A thread-safe, concurrency-safe in-memory ticket hold engine.

    Implements business rules:
      R1: Seat held by at most 1 user at a time, sold at most once.
      R2: User may hold at most 4 seats at once.
      R3: Expired hold cannot be confirmed unless uncontested.
      R4: Holds are final and never extended.
      R5: Retrying hold on already held seat is idempotent.
      R6: hold_many is atomic (all-or-nothing).
    """

    MAX_USER_HOLDS = 4

    def __init__(self, clock: Optional[Clock] = None) -> None:
        self._clock: Clock = clock if clock is not None else SystemClock()
        self._meta_lock = threading.Lock()

        # Dynamic fine-grained locks per resource
        self._seat_locks: Dict[str, threading.Lock] = {}
        self._user_locks: Dict[str, threading.Lock] = {}

        # Internal state stores
        self._seats: Dict[str, _SeatInternal] = {}
        self._holds: Dict[str, HoldRecord] = {}
        self._user_holds: Dict[str, Set[str]] = defaultdict(set)

    def _get_seat_lock(self, seat_id: str) -> threading.Lock:
        with self._meta_lock:
            if seat_id not in self._seat_locks:
                self._seat_locks[seat_id] = threading.Lock()
            return self._seat_locks[seat_id]

    def _get_user_lock(self, user_id: str) -> threading.Lock:
        with self._meta_lock:
            if user_id not in self._user_locks:
                self._user_locks[user_id] = threading.Lock()
            return self._user_locks[user_id]

    def _get_or_create_seat(self, seat_id: str) -> _SeatInternal:
        if seat_id not in self._seats:
            self._seats[seat_id] = _SeatInternal(seat_id=seat_id)
        return self._seats[seat_id]

    def hold(self, seat_id: str, user_id: str, ttl_seconds: float) -> str:
        """Holds a single seat for user_id with specified TTL in seconds.

        Returns hold_id on success, or raises TicketEngineError on failure.
        """
        results = self.hold_many(user_id, [seat_id], ttl_seconds)
        return results[0]

    def hold_many(self, user_id: str, seat_ids: List[str], ttl_seconds: float) -> List[str]:
        """Atomically holds multiple seats for user_id (all-or-nothing).

        Guarantees no deadlocks by acquiring user lock followed by seat locks
        in globally sorted lexicographical order.
        """
        if not user_id or not isinstance(user_id, str):
            raise ValueError("user_id must be a non-empty string")
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")
        if not seat_ids:
            return []

        now = self._clock.now()
        unique_seats = sorted(set(seat_ids))

        user_lock = self._get_user_lock(user_id)
        seat_locks = [self._get_seat_lock(s) for s in unique_seats]

        # Strict 2-tier lock acquisition:
        # Tier 1: User lock
        # Tier 2: Seat locks in ascending lexicographical order
        user_lock.acquire()
        acquired_seat_locks: List[threading.Lock] = []
        try:
            for slock in seat_locks:
                slock.acquire()
                acquired_seat_locks.append(slock)

            # 1. Determine currently active seats held by this user
            actively_held_seats: Set[str] = set()
            for hid in list(self._user_holds[user_id]):
                with self._meta_lock:
                    h = self._holds.get(hid)
                if h is None:
                    continue
                # An active hold must not be released/confirmed/superseded,
                # must not be expired, and must still be the current hold on the seat
                seat_obj = self._get_or_create_seat(h.seat_id)
                if (
                    not h.released
                    and not h.confirmed
                    and not h.superseded
                    and h.expires_at > now
                    and seat_obj.current_hold_id == h.hold_id
                ):
                    actively_held_seats.add(h.seat_id)

            # Seats in requested batch that user does NOT currently actively hold
            new_seats_to_acquire = [s for s in unique_seats if s not in actively_held_seats]

            # 2. Quota check (R2: max 4 seats per user)
            if len(actively_held_seats) + len(new_seats_to_acquire) > self.MAX_USER_HOLDS:
                raise HoldLimitExceededError(
                    f"User '{user_id}' cannot hold more than {self.MAX_USER_HOLDS} seats "
                    f"(currently holding {len(actively_held_seats)}, requested {len(new_seats_to_acquire)} new)"
                )

            # 3. Availability check across all requested seats
            for s in unique_seats:
                seat_obj = self._get_or_create_seat(s)
                if seat_obj.sold_to is not None:
                    raise SeatAlreadySoldError(f"Seat '{s}' is already sold to user '{seat_obj.sold_to}'")

                if seat_obj.current_hold_id is not None:
                    with self._meta_lock:
                        cur_hold = self._holds.get(seat_obj.current_hold_id)

                    if cur_hold and not cur_hold.released and not cur_hold.superseded:
                        if cur_hold.expires_at > now:
                            # Hold is currently active
                            if cur_hold.user_id != user_id:
                                raise SeatAlreadyHeldError(
                                    f"Seat '{s}' is actively held by user '{cur_hold.user_id}'"
                                )
                            # If held by this user, it's an idempotent retry (allowed)

            # 4. Atomic mutation: all checks passed
            seat_to_hold_id: Dict[str, str] = {}
            for s in unique_seats:
                seat_obj = self._get_or_create_seat(s)
                if s in actively_held_seats:
                    # Idempotent retry on actively held seat (R5 & R4):
                    # Keep existing hold_id, never extend TTL
                    seat_to_hold_id[s] = seat_obj.current_hold_id  # type: ignore[assignment]
                else:
                    # Supersede any previous expired/released hold on this seat
                    if seat_obj.current_hold_id is not None:
                        with self._meta_lock:
                            old_h = self._holds.get(seat_obj.current_hold_id)
                            if old_h:
                                old_h.superseded = True

                    # Allocate new hold
                    new_hid = f"hold_{uuid.uuid4().hex[:12]}"
                    new_record = HoldRecord(
                        hold_id=new_hid,
                        seat_id=s,
                        user_id=user_id,
                        created_at=now,
                        expires_at=now + ttl_seconds,
                    )
                    with self._meta_lock:
                        self._holds[new_hid] = new_record
                    self._user_holds[user_id].add(new_hid)
                    seat_obj.current_hold_id = new_hid
                    seat_to_hold_id[s] = new_hid

            # Preserve the caller's input order and duplicates
            return [seat_to_hold_id[s] for s in seat_ids]

        finally:
            for slock in reversed(acquired_seat_locks):
                slock.release()
            user_lock.release()

    def confirm(self, hold_id: str) -> str:
        """Confirms a hold, transitioning the seat to SOLD.

        Per R3: An expired hold can be confirmed if nobody else took the seat in the meantime.
        """
        with self._meta_lock:
            hold = self._holds.get(hold_id)
        if hold is None:
            raise HoldNotFoundError(f"Hold '{hold_id}' not found")

        user_lock = self._get_user_lock(hold.user_id)
        seat_lock = self._get_seat_lock(hold.seat_id)

        user_lock.acquire()
        try:
            seat_lock.acquire()
            try:
                if hold.confirmed:
                    raise HoldAlreadyConfirmedError(f"Hold '{hold_id}' is already confirmed")
                if hold.released:
                    raise HoldAlreadyReleasedError(f"Hold '{hold_id}' has already been released")
                if hold.superseded:
                    raise HoldInvalidatedError(
                        f"Hold '{hold_id}' expired and the seat was taken by someone else"
                    )

                seat_obj = self._get_or_create_seat(hold.seat_id)
                if seat_obj.sold_to is not None:
                    raise SeatAlreadySoldError(f"Seat '{hold.seat_id}' is already sold to '{seat_obj.sold_to}'")

                if seat_obj.current_hold_id != hold.hold_id:
                    raise HoldInvalidatedError(
                        f"Seat '{hold.seat_id}' is no longer held by hold '{hold_id}'"
                    )

                # Transition seat to SOLD
                seat_obj.sold_to = hold.user_id
                seat_obj.current_hold_id = None
                hold.confirmed = True

                self._user_holds[hold.user_id].discard(hold_id)
                return "OK"
            finally:
                seat_lock.release()
        finally:
            user_lock.release()

    def release(self, hold_id: str) -> str:
        """Releases a hold immediately, freeing the seat."""
        with self._meta_lock:
            hold = self._holds.get(hold_id)
        if hold is None:
            raise HoldNotFoundError(f"Hold '{hold_id}' not found")

        user_lock = self._get_user_lock(hold.user_id)
        seat_lock = self._get_seat_lock(hold.seat_id)

        user_lock.acquire()
        try:
            seat_lock.acquire()
            try:
                if hold.confirmed:
                    raise HoldAlreadyConfirmedError(
                        f"Cannot release hold '{hold_id}': seat has already been purchased"
                    )
                if hold.released:
                    raise HoldAlreadyReleasedError(f"Hold '{hold_id}' is already released")

                seat_obj = self._get_or_create_seat(hold.seat_id)
                if seat_obj.current_hold_id == hold.hold_id:
                    seat_obj.current_hold_id = None

                hold.released = True
                self._user_holds[hold.user_id].discard(hold_id)
                return "OK"
            finally:
                seat_lock.release()
        finally:
            user_lock.release()

    def seat_status(self, seat_id: str) -> SeatStatus:
        """Returns the current status of the seat: FREE | HELD(user, expires_at) | SOLD(user)."""
        seat_lock = self._get_seat_lock(seat_id)
        with seat_lock:
            seat_obj = self._get_or_create_seat(seat_id)
            if seat_obj.sold_to is not None:
                return SeatStatus(status=SeatState.SOLD, user_id=seat_obj.sold_to)

            if seat_obj.current_hold_id is not None:
                with self._meta_lock:
                    hold = self._holds.get(seat_obj.current_hold_id)

                if hold and not hold.released and not hold.superseded:
                    now = self._clock.now()
                    if hold.expires_at > now:
                        return SeatStatus(
                            status=SeatState.HELD,
                            user_id=hold.user_id,
                            expires_at=hold.expires_at,
                        )

            return SeatStatus(status=SeatState.FREE)
