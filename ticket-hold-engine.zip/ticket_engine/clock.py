from typing import Protocol
import time


class Clock(Protocol):
    """Protocol for time providers."""

    def now(self) -> float:
        """Returns the current monotonic timestamp in seconds."""
        ...


class SystemClock:
    """Production clock backed by system time."""

    def now(self) -> float:
        return time.time()


class FakeClock:
    """Injectable deterministic clock for testing without sleep calls."""

    def __init__(self, initial_time: float = 0.0) -> None:
        self._current_time: float = initial_time

    def now(self) -> float:
        return self._current_time

    def advance(self, seconds: float) -> None:
        if seconds < 0:
            raise ValueError(f"Time cannot move backward (attempted {seconds}s)")
        self._current_time += seconds

    def set(self, timestamp: float) -> None:
        if timestamp < self._current_time:
            raise ValueError(f"Time cannot move backward (target {timestamp} < current {self._current_time})")
        self._current_time = timestamp
