from dataclasses import dataclass
from enum import Enum
from typing import Optional


class SeatState(str, Enum):
    FREE = "FREE"
    HELD = "HELD"
    SOLD = "SOLD"


@dataclass(frozen=True)
class SeatStatus:
    status: SeatState
    user_id: Optional[str] = None
    expires_at: Optional[float] = None

    def __str__(self) -> str:
        if self.status == SeatState.FREE:
            return "FREE"
        if self.status == SeatState.HELD:
            return f"HELD({self.user_id}, {self.expires_at})"
        if self.status == SeatState.SOLD:
            return f"SOLD({self.user_id})"
        return f"{self.status.value}"


@dataclass
class HoldRecord:
    hold_id: str
    seat_id: str
    user_id: str
    created_at: float
    expires_at: float
    superseded: bool = False
    confirmed: bool = False
    released: bool = False


class TicketEngineError(Exception):
    """Base exception for all ticket hold engine errors."""
    pass


class SeatAlreadySoldError(TicketEngineError):
    """Raised when attempting to hold or confirm a seat that has already been sold."""
    pass


class SeatAlreadyHeldError(TicketEngineError):
    """Raised when attempting to hold a seat currently held by another user."""
    pass


class HoldLimitExceededError(TicketEngineError):
    """Raised when a user attempts to hold more than 4 seats simultaneously."""
    pass


class HoldNotFoundError(TicketEngineError):
    """Raised when a hold_id cannot be found in the engine."""
    pass


class HoldAlreadyConfirmedError(TicketEngineError):
    """Raised when attempting to confirm or release an already confirmed hold."""
    pass


class HoldAlreadyReleasedError(TicketEngineError):
    """Raised when attempting to confirm or release an already released hold."""
    pass


class HoldInvalidatedError(TicketEngineError):
    """Raised when an expired hold cannot be confirmed because the seat was retaken or superseded."""
    pass
