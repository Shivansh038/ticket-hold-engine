# Ticket Hold Engine ("Nobody Gets the Same Seat Twice")

A concurrency-safe in-memory ticket hold and reservation engine built with Python standard library (zero external dependencies).

---

## Candidate Information

* **Candidate**: Shivansh
* **Email**: e23cseu0124@bennett.edu.in
* **GitHub Profile**: [@Shivansh038](https://github.com/Shivansh038)
* **Repository**: [https://github.com/Shivansh038/ticket-hold-engine](https://github.com/Shivansh038/ticket-hold-engine)
* **Assessment**: SDE Intern Assignment 2

---

## How to Run the Tests

No setup or `pip install` required. Run directly with Python 3:

```bash
# Run all tests (unit tests, concurrency stress test, model test)
python -m unittest discover tests
```

### Specific Test Suites
* **Unit Tests (Rules R1–R6 & Edge Cases)**:
  `python -m unittest tests.test_engine`
* **Concurrency Stress Test (Invariant assertions under high contention)**:
  `python -m unittest tests.test_concurrency`
* **Model-Based Randomized Test (Differential comparison vs reference oracle)**:
  `python -m unittest tests.test_model`

---

## Architecture & Concurrency Highlights

* **Deadlock-Free Locking**: In `hold_many`, seat IDs are canonically sorted in ascending lexicographical order (`sorted(set(seat_ids))`). Locks follow a strict 2-tier hierarchy (User Lock $\rightarrow$ Sorted Seat Locks), making circular waits impossible.
* **Injectable Clock**: Decoupled behind the `Clock` protocol with `FakeClock` / `ThreadSafeFakeClock`. Tests run in milliseconds with zero `time.sleep()`.
* **Lazy Expiry**: Expirations are evaluated on access against `clock.now()`, avoiding background timer threads and drift.

---

## Rule Resolutions & Key Behaviors

1. **R1 (Single Hold / Single Sale)**: A seat is held by at most 1 user at a time and sold at most once.
2. **R2 (4-Seat Quota)**: Max 4 active holds per user. Expired holds do not block quota.
3. **R3 (Late Confirmation)**: Expired holds can be confirmed if and only if the seat remained uncontested (no one else took it).
4. **R4 (No Extensions)**: Hold TTLs are immutable. Retries never extend expiration.
5. **R5 (Idempotent Retry)**: Retrying `hold()` on an actively held seat returns the same `hold_id` without extending the TTL.
6. **R6 (All-or-Nothing)**: `hold_many` is atomic. If any seat is unavailable or quota is exceeded, 0 seats are held.

---

## What Works & What Doesn't

* **What Works**:
  * Safe under high concurrency with multi-threaded stress verification.
  * Invariants strictly verified: no double sales, no user $> 4$ holds, no confirmed expired-and-retaken holds.
  * 500-step randomized differential testing against a single-threaded reference implementation.
* **What Doesn't**:
  * **In-Memory Only**: State lives in RAM; restart loses active holds. Production requires persistent storage (e.g. Postgres / Redis).
  * **Single-Process**: Multi-node deployments require distributed leases and monotonic fencing tokens to handle clock skew (detailed in `BUGS_I_FEAR.md`).

---

## Required Documentation

* [`DECISIONS.md`](DECISIONS.md) — Detailed spec ambiguity & rule conflict analysis.
* [`BUGS_I_FEAR.md`](BUGS_I_FEAR.md) — Analysis of distributed clock drift and production mitigations.
* [`AI_USAGE.md`](AI_USAGE.md) — Tool disclosure log (`none`).
