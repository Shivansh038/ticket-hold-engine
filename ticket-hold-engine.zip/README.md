# Ticket Hold Engine ("Nobody Gets the Same Seat Twice")

A concurrency-safe in-memory ticket reservation and hold engine library designed for high-contention ticketing scenarios. Built with zero external dependencies using Python's standard library.

---

## Architecture & Concurrency Model

### 1. Two-Tier Hierarchical Locking (Deadlock Freedom)
To eliminate deadlocks when concurrent users request overlapping sets of seats in differing orders (e.g. User A requesting `[s1, s2]` while User B requests `[s2, s1]`):
* **Lexicographical Sorting**: All multi-seat requests sort target seat IDs in strictly ascending order (`sorted(set(seat_ids))`).
* **Strict Lock Hierarchy**:
  * **Tier 1 (User Lock)**: `_user_locks[user_id]` is acquired first to synchronize quota accounting.
  * **Tier 2 (Seat Locks)**: `_seat_locks[seat_id]` are acquired sequentially in ascending lexicographical order.
* Because all threads acquire locks in the exact same global order, circular wait conditions cannot occur, guaranteeing deadlock freedom.

### 2. Injectable Clock & Deterministic Expiry
* Time queries are decoupled behind the `Clock` protocol.
* In production, `SystemClock` uses system time.
* In tests, `FakeClock` / `ThreadSafeFakeClock` allow manual time manipulation (`clock.advance(delta)`), enabling comprehensive time-dependent testing without calling `time.sleep()`.
* **Lazy Expiration**: Hold expiration is evaluated lazily at the instant of access, avoiding the race conditions and overhead of background timer threads.

---

## Business Rules & Resolution of Conflicts

All business rules from the specification are implemented and verified:

* **R1 (Single Hold, Single Sale)**: A seat can be held by at most one user at a time and sold at most once.
* **R2 (Quota)**: A user may hold at most 4 seats simultaneously. Only active (unexpired, unreleased) holds count against this quota.
* **R3 (Late Confirmation if Uncontested)**: An expired hold can be confirmed if and only if nobody else has taken the seat in the meantime. If another user held the seat (even if later released), the expired hold is marked superseded and rejected.
* **R4 (Holds Never Extended)**: Hold expiration timestamps are immutable. Idempotent retries or queries never extend the original expiration.
* **R5 (Idempotent Retry)**: Retrying `hold()` on a seat already actively held by the same user returns the existing `hold_id` without extending the TTL or consuming additional quota.
* **R6 (`hold_many` Atomicity)**: Multi-seat reservations are strictly all-or-nothing. If any seat is unavailable or if the batch would exceed the user's 4-seat quota, zero seats are reserved.

*(For detailed rationale on the spec contradictions between R3/R4/R5 and R2/R6, see [DECISIONS.md](DECISIONS.md)).*

---

## Project Structure

```text
ticket-hold-engine/
├── ticket_engine/
│   ├── __init__.py      # Public exports
│   ├── clock.py         # Clock protocol, SystemClock, and FakeClock
│   ├── models.py        # SeatStatus, SeatState, HoldRecord, custom exceptions
│   └── engine.py        # Core TicketHoldEngine implementation
├── tests/
│   ├── __init__.py
│   ├── test_engine.py   # Unit tests covering R1-R6 and conflict edge cases
│   ├── test_concurrency.py # Multi-threaded stress tests verifying invariants
│   └── test_model.py    # Randomized differential testing vs single-threaded oracle
├── DECISIONS.md         # Detailed conflict analysis and design decisions
├── BUGS_I_FEAR.md       # Analysis of distributed clock drift and production mitigation
├── AI_USAGE.md          # Tool disclosure log
├── .gitignore
└── README.md
```

---

## How to Run Tests

The test suite requires no external dependencies (`pip` packages are not required):

### Run All Tests
```bash
python -m unittest discover tests
```

### Run Specific Test Modules
* **Unit tests (R1-R6 rules & edge cases)**:
  ```bash
  python -m unittest tests.test_engine
  ```
* **Concurrency stress tests (Asserts invariants & deadlock freedom under heavy thread contention)**:
  ```bash
  python -m unittest tests.test_concurrency
  ```
* **Model-based randomized tests (Compares engine against reference oracle across hundreds of random operations)**:
  ```bash
  python -m unittest tests.test_model
  ```

*Both stress tests and model-based tests print their random seed on execution (e.g. `Reproducible seed: 48778`), allowing any failure sequence to be reproduced deterministically by setting the environment variables `CONCURRENCY_TEST_SEED` or `MODEL_TEST_SEED`.*

---

## What Works
* Thread-safe, atomic seat reservations under heavy concurrency.
* Strict deadlock prevention via canonical lock hierarchy.
* 100% test coverage over all 6 business rules and edge-case conflict resolutions.
* Comprehensive invariant assertions:
  1. No double sales under multi-threaded races.
  2. No user ever exceeds 4 active holds.
  3. No confirmed expired-and-retaken holds.
* Differential verification against a single-threaded reference oracle across randomized operation sequences.
* Fully deterministic time testing with zero sleep calls.

---

## What Doesn't (Current Limitations)
* **In-Memory Only**: State is stored in-process RAM. If the application process crashes or restarts, all reservations and sales are lost. A production system requires write-ahead logging or persistence (e.g., PostgreSQL / Redis).
* **Single Node**: Does not handle distributed consensus or multi-node clock skew out of the box (see [BUGS_I_FEAR.md](BUGS_I_FEAR.md) for how this should be handled across distributed instances).
