# Bugs I Fear: Distributed Clock Skew and Lease Ambiguity

## The Bug Class: Distributed Clock Skew & Non-Monotonic System Time

### Why the Current Test Suite Cannot Catch It
In our test suite, all threads interact with a single injected clock (`FakeClock` or `ThreadSafeFakeClock`). The clock in our tests satisfies three artificial guarantees:
1. **Strict Monotonicity**: Time never moves backward ($\Delta t \ge 0$).
2. **Instantaneous Uniformity**: All threads observe the exact same `now()` value simultaneously.
3. **Zero Jitter**: There are no leap seconds, virtualization hypervisor pauses, or NTP step corrections.

In the real world, ticketing systems do not run in a single Python process on a single core. They run across multiple application processes, containers, or distributed nodes sitting behind a load balancer.

If two nodes have clocks that drift by even 500 milliseconds (standard NTP drift, container migration jitter, or virtualization time dilation):
* **Node 1 (Clock ahead by +1s)**: Thinks Hold A (10s TTL) has reached $t=11s$ and is expired. It permits User B to grab the seat.
* **Node 2 (Clock on time)**: Receives User A's payment confirmation at $t=9.8s$. Node 2 believes Hold A is still active and uncontested, confirming the purchase.
* **The catastrophic outcome**: Both users believe they purchased the same seat, or an expired hold is confirmed simultaneously with a new hold on another node.

Furthermore, if a host system's NTP daemon performs a step adjustment (jumping backward by a second rather than slewing), an expired hold could abruptly become active again, breaking expiration invariants.

---

## How to Catch and Mitigate This in Production

### 1. Monotonic Timers Instead of Wall Clocks
Within a single process, never calculate lease expiration using wall-clock timestamps (`time.time()` or system `gettimeofday()`), which can jump backward on NTP sync. Always base internal TTL deadlines on monotonic clocks (`time.monotonic()` or Linux `CLOCK_MONOTONIC_RAW`), converting to wall-clock time only for user-facing UI displays.

### 2. Distributed Leases with Fencing Tokens
In a distributed architecture, do not rely on local node clocks to decide whether a lease is valid. Instead:
* Use a centralized distributed coordinator (e.g., Redis with Redlock, etcd, or a relational database with `SELECT ... FOR UPDATE` and transactional version stamps).
* Assign a monotonically incrementing **fencing token** (or Raft term/index) to each hold. When confirming a seat, the storage layer rejects any confirmation whose fencing token is older than the current highest token granted on that seat, eliminating stale confirmation races regardless of clock skew.

### 3. Production Monitoring & Chaos Testing
To catch this before users do:
* **Node Clock Drift Telemetry**: Run `chrony` or `systemd-timesyncd` with Prometheus node-exporter metrics alerting whenever any cluster node's NTP offset exceeds 50 milliseconds (`node_timex_offset_seconds > 0.05`).
* **Real-time Invariant Pipeline**: Stream all hold, confirm, and release events to an audit consumer (e.g., Kafka / Flink). Assert in near-real-time that no two events claim the same seat concurrently, raising high-priority PagerDuty alerts on any lease collision.
* **Chaos Testing (Jepsen-style)**: Run automated end-to-end tests in staging with clock-skew injection (e.g., using Chaos Mesh to skew node clocks by $\pm 2$ seconds while running concurrent hold/confirm transactions) to verify that fencing tokens protect seat integrity.
