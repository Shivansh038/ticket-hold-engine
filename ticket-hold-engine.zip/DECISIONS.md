# Architectural Decisions & Rule Conflict Analysis

This document outlines the ambiguities, contradictions, and edge cases discovered in the specification, along with the reasoning behind the resolutions chosen before implementation.

---

## 1. Conflict: R3 vs. R4 vs. R5 (The Hold Lifecycle Catch)

### The Rules
* **R3**: A hold expires after its TTL; an expired hold can never be confirmed... unless nobody else has taken the seat in the meantime.
* **R4**: Holds are final and are never extended.
* **R5**: If a user who already holds a seat calls `hold()` on the same seat again, treat it as an idempotent retry.

### Contradictions & Ambiguities

#### Case 1A: What happens to TTL when `hold()` is retried on an active hold?
* If User A holds seat `s1` with 10s TTL, and at $t=5s$ retries `hold(s1, User A, 10s)`:
* **The conflict**: Should the TTL reset to $5 + 10 = 15s$, or stay at $10s$?
* **Decision**: The expiration timestamp remains at $10s$. Per **R4**, "Holds are final and are never extended." Resetting TTL on retry would allow a client to hoard a seat indefinitely by repeatedly pinging `hold()`. The retry is strictly idempotent: it returns the existing `hold_id` without altering `expires_at`.

#### Case 1B: What happens if `hold()` is called on an *expired* hold that is uncontested?
* User A holds `s1` until $t=10s$. At $t=12s$, nobody has touched `s1`. User A calls `hold(s1, User A, 10s)`.
* **The conflict**: Is this an idempotent retry under **R5**, or a new hold? If idempotent, does it return the expired hold (useless) or extend it (violating **R4**)?
* **Decision**: At $t=12s$, the hold has expired. User A does **not** "already hold" the seat. The seat is `FREE`. Therefore, this call is **not** an idempotent retry of an active hold; it is treated as a fresh hold request. It issues a new `hold_id` with a new TTL and increments the active hold quota. The expired hold is superseded.

#### Case 1C: What is `seat_status()` for an expired, uncontested hold?
* **The conflict**: If `seat_status()` returned `HELD` after TTL, other users could not take the seat, making the TTL meaningless.
* **Decision**: Once $t \ge expires\_at$, `seat_status(s1)` returns `FREE`. Any other user can immediately claim the seat. However, if the original user calls `confirm(hold_id)` while the seat is still uncontested, confirmation succeeds per **R3**. The hold was never extended; it simply enjoyed optimistic confirmation while the seat sat idle.

#### Case 1D: What constitutes "taken in the meantime"?
* Suppose User A's hold on `s1` expires at $t=10s$. At $t=12s$, User B holds `s1`. At $t=13s$, User B releases `s1`. At $t=15s$, User A attempts to `confirm(hold_id_A)`.
* **The conflict**: At $t=15s$, the seat is currently free. Can User A confirm?
* **Decision**: **No.** User B "took the seat in the meantime" at $t=12s$. When User B took the seat, User A's claim was permanently severed (marked `superseded`). Even if User B later cancels, User A's expired hold cannot be resurrected.

---

## 2. Conflict: R2 vs. R6 (Quota and Atomic Multi-Seat Holds)

### The Rules
* **R2**: A user may hold at most 4 seats at once.
* **R6**: Support `hold_many(user, [seats])` which is all-or-nothing.

### Contradictions & Ambiguities

#### Case 2A: Quota accounting for active vs. expired holds
* **The conflict**: If a user let 4 previous holds expire without confirming or releasing, can they hold seats again?
* **Decision**: Yes. Only **active** (`now < expires_at` and unreleased/unconfirmed) holds count toward the 4-seat limit. Expired holds no longer grant exclusive reservation and must not lock users out of future reservations.

#### Case 2B: Partial holds and quota overflow in `hold_many`
* Suppose User A actively holds 2 seats. User A calls `hold_many(User A, [s3, s4, s5])` (3 seats).
* **The conflict**: 2 existing + 3 new = 5 seats ($> 4$).
* **Decision**: All-or-nothing atomicity. The entire operation fails immediately with `HoldLimitExceededError`. Zero new seats are reserved.

#### Case 2C: Overlapping / duplicate seats in `hold_many`
* User A holds `s1`. User A calls `hold_many(User A, [s1, s2, s3])`.
* **Decision**: `s1` is already held by User A, so per **R5**, it is treated idempotently. The newly requested seats are only `{s2, s3}` (2 seats). Since $1 + 2 = 3 \le 4$, the call succeeds. The returned list includes the existing `hold_id` for `s1` and newly created `hold_ids` for `s2` and `s3`. Duplicate seat IDs within the input arguments are also deduplicated.

#### Case 2D: Return type of `hold_many`
* **Decision**: `hold_many` returns a list of hold IDs (`list[str]`) matching the input seat list. This allows callers to perform standard seat-level operations (`confirm(hold_id)`, `release(hold_id)`) uniformly without requiring composite batch hold semantics or partial confirm complexities.

---

## 3. Concurrency & Locking Architecture

### The Problem
If User 1 calls `hold_many([s1, s2])` and User 2 calls `hold_many([s2, s1])`, acquiring seat locks in input order creates an immediate deadlock (circular wait). Furthermore, user quota checks across multiple seats require synchronization across both seat states and user states.

### The Locking Strategy: Hierarchical Two-Phase Lock Acquisition
To ensure maximum concurrency, atomic execution, and zero deadlocks:

1. **Global Canonical Ordering**:
   Whenever multiple seats must be locked, their identifiers are sorted lexicographically: `sorted_seats = sorted(set(seats))`.

2. **Strict Lock Hierarchy**:
   Every multi-lock acquisition follows a strict 2-tier hierarchy:
   * **Tier 1 (User Lock)**: `user_lock(user_id)` is acquired first to protect quota calculation.
   * **Tier 2 (Seat Locks)**: `seat_lock(seat_id)` locks are acquired sequentially in strictly ascending lexicographical order.

3. **Deadlock-Free Guarantee**:
   Because all threads acquire the user lock before any seat locks, and all seat locks follow the same total order, the resource allocation graph contains no cycles. Deadlock is mathematically impossible.

4. **Atomic Rollback / Validation**:
   In `hold_many`, validation is performed across all target seats under the held locks before any state mutation occurs. If any seat is sold, held by another user, or if quota is exceeded, the function raises an exception without modifying any seat or hold record.

---

## 4. Clock and Expiration Design

* **Clock Injection**: The engine accepts an injectable `Clock` protocol (defaulting to system time `time.time`). Tests use `FakeClock` which allows manual deterministic time advancement (`fake_clock.advance(...)`) without calling `time.sleep()`.
* **Lazy Expiration**: Expiration is calculated lazily during read/write operations by comparing `clock.now()` against `expires_at`. This avoids the nondeterminism, race conditions, and overhead of background timer threads.
